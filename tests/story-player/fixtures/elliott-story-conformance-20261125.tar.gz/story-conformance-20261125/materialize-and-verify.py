#!/usr/bin/env python3
"""Corpus integrity/mutation verifier, not a story parser/adapter conformance test.
With --materialize, decode the one base64 carrier inside this corpus directory.
No production code, network, MV2 reader, cue runner, or player is imported.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path


def verify(materialize=False):
    home = Path(__file__).resolve().parent
    manifest = json.loads((home / "manifest.json").read_text(encoding="utf-8"))
    rows = manifest["specimens"]
    assert len(rows) == 18
    assert len({row["id"] for row in rows}) == len(rows)
    baseline = (home / "specimens/01-baseline.json").read_bytes()
    assert hashlib.sha256(baseline).hexdigest() == manifest["baseline"]["sha256"]
    assert len(baseline) == manifest["baseline"]["byteLength"]
    baseline_text = baseline.decode("utf-8", errors="strict")
    source = json.loads(baseline_text)
    checked = []
    for row in rows:
        storage = row["storage"]
        path = home / storage["path"]
        assert path.resolve().is_relative_to(home)
        stored = path.read_bytes()
        if storage["encoding"] == "base64":
            assert stored.endswith(b"\n")
            data = base64.b64decode(stored[:-1], validate=True)
            assert base64.b64encode(data) + b"\n" == stored
            if materialize:
                target = home / storage["materializedPath"]
                assert target.resolve().is_relative_to(home)
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    assert target.read_bytes() == data, "Refusing to overwrite different bytes"
                else:
                    target.write_bytes(data)
                assert target.read_bytes() == data
        else:
            data = stored
            data.decode("utf-8", errors="strict")
        assert len(data) == row["byteLength"], row["id"]
        assert hashlib.sha256(data).hexdigest() == row["sha256"], row["id"]
        assert row["sourceBoundId"] == "thornfield.story.v1:sha256:" + row["sha256"]
        mutation = row["mutation"]
        kind = mutation["kind"]
        if kind == "identity":
            expected = baseline
        elif kind == "format-only":
            # JS/Python string serialization differs in general; for this all-ASCII
            # fixture the declared four-space formatting is intentionally identical.
            expected = (json.dumps(source, indent=4, ensure_ascii=False) + "\n").encode("utf-8")
            assert json.loads(data) == source
            assert data != baseline
        elif kind == "exact-text-splice":
            assert baseline_text.count(mutation["oldText"]) == 1
            expected = baseline_text.replace(mutation["oldText"], mutation["newText"], 1).encode("utf-8")
        elif kind == "byte-replace":
            offset = mutation["offset"]
            old = bytes.fromhex(mutation["oldHex"])
            new = bytes.fromhex(mutation["newHex"])
            assert baseline[offset:offset + len(old)] == old
            expected = baseline[:offset] + new + baseline[offset + len(old):]
        else:
            raise AssertionError(kind)
        assert data == expected, row["id"]
        if row["id"] == "03-invalid-utf8":
            try:
                data.decode("utf-8", errors="strict")
            except UnicodeDecodeError:
                pass
            else:
                raise AssertionError("invalid UTF-8 unexpectedly decoded")
        elif row["id"] == "04-invalid-json":
            try:
                json.loads(data.decode("utf-8"))
            except json.JSONDecodeError:
                pass
            else:
                raise AssertionError("invalid JSON unexpectedly parsed")
        else:
            # Shape comparisons only. This is not a duplicate-aware story reader.
            value = json.loads(data.decode("utf-8"))
            if row["id"] in ("05-duplicate-root-key", "06-duplicate-nested-key"):
                assert value == source
        checked.append(row["id"])
    cases = manifest["cases"]
    assert len(cases) == 19
    assert len({case["id"] for case in cases}) == len(cases)
    index = {row["id"]: row for row in rows}
    for case in cases:
        specimen = index[case["specimen"]]
        if case["id"] == "19-digest-mismatch":
            assert case["specimen"] == "01-baseline"
            assert case["suppliedDigest"] != specimen["sha256"]
            assert len(case["suppliedDigest"]) == 64
            int(case["suppliedDigest"], 16)
        else:
            assert case["suppliedDigest"] == specimen["sha256"]
        if case["expectedPolicyOutcome"] == "accept":
            assert case["expectedCapsuleId"] == specimen["sourceBoundId"]
    counts = manifest["counts"]
    assert counts == dict(specimens=18, positiveSpecimens=2, negativeSpecimens=16,
                          invocations=19, positiveInvocations=2, negativeInvocations=17,
                          rawUtf8Files=17, base64Carriers=1)
    print(json.dumps(dict(boundary="corpus byte integrity and declared mutations only",
                          specimensChecked=len(checked), invocationsChecked=len(cases),
                          materialized=materialize, adapterExecuted=False), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--materialize", action="store_true")
    verify(parser.parse_args().materialize)

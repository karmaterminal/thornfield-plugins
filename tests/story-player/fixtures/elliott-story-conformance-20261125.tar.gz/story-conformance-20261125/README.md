# Story conformance byte corpus — 2026-11-25

Test-only preparation for thornfield-plugins#20. Cael owns the adapter/player; Rune owns the schema/reader. No production code or repository files changed.

## Contents and boundary

- manifest.json: 18 specimen rows (2 policy-positive, 16 policy-negative) and 19 invocation rows (the extra row supplies an incorrect digest for unchanged baseline bytes).
- specimens/: 17 raw UTF-8 files plus one lossless base64 carrier for invalid UTF-8. The carrier is NOT adapter input.
- materialize-and-verify.py: standalone standard-library integrity/mutation verifier, NOT a fake story reader or adapter. It optionally creates only materialized/03-invalid-utf8.bin inside this directory. It does not import production code or assert adapter acceptance.
- self-check.json: readback checks actually performed in OpenClaw JavaScript, including SHA-256 vectors, exact fixture pin, byte comparisons, hashes/counts and specimen-local intended mutation facts.
- SHA256SUMS: exact stored artifact hashes, including the carrier hash separately from its decoded source-byte digest in manifest.json. Does not hash itself.

The source fixture is Rune's tests/story-player/rune-seven-eleven-score.json, 5662 original bytes, SHA-256 05a0666337e78fa4c9a369f71cb66442400a5fd887f421aaa2a69198970c2ceb. Silas Markdown is not included or treated as graph input. The child read the fixture from the parent-supplied isolated checkout but did not independently resolve Git HEAD.

Baseline bytes are exact. The second control is semantically equal four-space JSON with a different raw-byte digest and content-addressed ID; neither control authorizes reserialization of imported source_bytes. All case digests match actual raw bytes except the explicitly named manifest-only digest-mismatch case.

## How to consume

No local command-launch or binary-file-write tool was available to this child. The invalid-UTF-8 negative is therefore supplied through base64, verified after decoding in JavaScript, with its intended input-byte hash/length in the manifest. It is not yet a raw .bin on disk. The following command is provided for the parent/authorized test harness; it was NOT executed by this child:

    python3 materialize-and-verify.py --materialize

Run it from this directory, or use the script's absolute path. Without --materialize it checks the carrier without writing. Then give the adapter each row's actual bytes: direct file bytes for encoding=utf-8; decoded bytes / materializedPath for encoding=base64. Supply cases[].suppliedDigest separately. Do not use storage-carrier hashes as source-byte digests.

Adapter API/result/error mapping is deliberately unresolved. expectedPolicyOutcome and expectedCapsuleId are owner-policy expectations, NOT observed production results. No acceptance test or callable adapter exists in this deliverable. No MV2 read/run, cues, network fetches, scheduling, save/load/replay, live player or service action occurred.

## Mutation isolation and unavoidable implications

Each negative has one primary authored rule mutation, reconstructed from exact baseline bytes via its manifest mutation. This is not a promise of one possible validator diagnostic. Graph invariants are not independent:

- a dangling route has no explicit terminal;
- empty choices are not a valid route and cannot terminate;
- a reachable cycle admits an infinite path;
- deleting a choice target can also remove reachability for its exclusive descendants.

Those consequences are named in row notes. 12-no-route deletes an interior route; 17-nonterminal-path deletes the explicit terminal marker. The latter is necessarily also a no-route witness. For a finite acyclic graph with fully resolving targets and exactly one valid route on every scene, every path already ends explicitly; an independent nonterminal-path negative satisfying all other graph predicates is mathematically unavailable. No error precedence or orthogonal production taxonomy is invented.

All mutations preserve metadata outside their specified graph/key location. Duplicate JSON key specimens repeat the SAME value so an ordinary last-wins parser would otherwise see baseline semantics; the nested example is sleeve.author. Duplicate scene IDs append an identical receipt occurrence. Choice-label duplication occurs within one scene, without assuming unresolved global label semantics. Numeric limits, cue/duration acceptance rules, exact shape and error API are not invented; open items are listed in manifest.json.

## Verification status

The JavaScript readback receipt is actual static corpus verification only. The standalone Python verifier was written/read back, not run or syntax-compiled here. A SHA-256 implementation checked standard empty/abc vectors and the externally pinned baseline before hashing artifacts. The parent should independently rerun standard-library hashing and review byte deltas before adapting this corpus to the eventual repository contract.

This finite preparation is complete. No worker, watch, publication, comments, install, service/config action or further continuation is armed.
